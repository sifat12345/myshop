

<nav class="navbar navbar-expand-lg navbar-light n_c">
<div class=" con_wid"> 


  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <div class="col-md-4"> 

      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('index')); ?>">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('products')); ?>">Products <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('admin.products')); ?>">Admin <span class="sr-only">(current)</span></a>
        </li>

      </ul>
 </div>

    <div class="col-md-4"> 
      <h2 class="m_s"> My Shop</h2>
    </div>

 <style>.ser{ margin-top: 3px;}  </style>

    <div class="col-md-4 fll"> 
      <div class="row"> 
       
         <div class="col-md-8  ser"> 
          <form class="form-inline my-2 my-lg-0" action="<?php echo route('search'); ?>" method="get">
             <input type="text" class="form-control" name="sear" placeholder="Product Name" aria-label="Recipient's username" aria-describedby="basic-addon2">
            <div class="input-group-append sr_bt">
              <button type="submit"><i class="fa fa-search" ></i> </button>
            </div>
          </form>
         </div>

    <div class="col-md-4"> 
          <ul class="navbar-nav ml-auto">
              <!-- Authentication Links -->
          <?php if(auth()->guard()->guest()): ?>
                  <a class=" nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>     
              <?php if(Route::has('register')): ?>
                   <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>    

              <?php endif; ?>
          <?php else: ?>
              <li class="nav-item dropdown">
                  <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                      <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                  </a>

                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                         onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();">
                          <?php echo e(__('Logout')); ?>

                      </a>

                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                      </form>
                  </div>
              </li>
          <?php endif; ?>
         </u>
           <!-- Edn Authentication Links -->
        </div>

     </div>
   </div>


  </div>

  </div>
</nav>
