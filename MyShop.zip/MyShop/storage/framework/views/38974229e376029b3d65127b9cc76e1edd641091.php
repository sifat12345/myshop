<?php $__env->startSection('content'); ?>
<!-- Sitebar Start--------------- -->
<div class="container mar_top"> 
  <div class="row"> 

 <?php echo $__env->make('parsial.product_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

   <div class="col-md-8">
    <div class="widget">
      <h3>Feature Product</h3>
        <div class="row"> 


  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-4"> 
               <div class="card " >

                   <div class="img_p"> 

                  <?php $i = 1; ?>
                  <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <?php if($i > 0): ?>
                    <img class="card-img-top" src="<?php echo e(asset('images/products/'. $image->image)); ?>" alt="Card image">
                  <?php endif; ?>

                  <?php $i--; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                   </div> `

                    <div class="card-body">
                      <h4 class="card-title">
                        <?php echo e($product->title); ?>

                      </h4>
                      <p class="card-text">   <?php echo e($product->price); ?>.Tk</p>
                    </div>
                 <a href="#" class="btn btn-primary">Add to Cart`</a>
               </div>
            </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   

       </div>      <!-- row -->
 
     </div>
    </div>   

   </div>     <!-- row -->
</div>     <!-- container  -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>