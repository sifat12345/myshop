 

       <div class="col-md-4"> 
        <div class="list-group"> 
          <a href="<?php echo e(route('admin.index')); ?>" class="list-group-item list-group-item-action">Admin </a>
          <a href="#" class="list-group-item list-group-item-action">Second</a>
          <a href="#" class="list-group-item list-group-item-action">Third</a>
        </div>
       </div>
