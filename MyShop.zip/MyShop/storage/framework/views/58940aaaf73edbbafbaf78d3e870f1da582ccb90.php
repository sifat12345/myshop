<?php $__env->startSection('content'); ?>
<div class="content"> 
    <h3>Contact Us</h3>
  <p>lker ekjrweporr oeprjp ertererqpot erpo iertoike rerotpertp'eor ertiert eroptgiker erti er  </p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>