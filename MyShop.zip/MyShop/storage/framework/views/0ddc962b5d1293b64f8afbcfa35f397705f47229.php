<?php $__env->startSection('content'); ?>
  <div class="main-panel">
    <div class="content-wrapper">

      <div class="card">
        <div class="card-header">
          Edit Product
        </div>
        <div class="card-body">
          <form action="<?php echo e(route('admin.product.update', $pr->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo $__env->make('admin.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="form-group">
              <label for="exampleInputEmail1">Title</label> 
              <input type="text" class="form-control" name="title" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($pr->title); ?>">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Description</label>
              <textarea rows="8" cols="80" name="description"  class="form-control"><?php echo e($pr->description); ?></textarea>
            </div>

            <div class="form-group">
              <label for="exampleInputEmail1">Price</label>
              <input type="number" name="price"  class="form-control" value="<?php echo e($pr->price); ?>"   id="exampleInputEmail1">
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Quantity</label>
              <input type="number" name="quantity"  class="form-control" value="<?php echo e($pr->quantity); ?>"  id="exampleInputEmail1">
            </div>


            <button type="submit" class="btn btn-primary">Update</button>
          </form>
        </div>
      </div>

    </div>
  </div>
  <!-- main-panel ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>