<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/css/bootstrap.min.css')); ?>" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/sifat.css')); ?>" crossorigin="anonymous">
    <title>My Shop</title>

  </head>

<body>

<div class="wrapper">

  <nav class="navbar navbar-expand-lg navbar-light bg-light">
<div class="container"> 


  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <div class="col-md-4"> 

      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('index')); ?>">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('products')); ?>">Products <span class="sr-only">(current)</span></a>
        </li>

  <!--       <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Dropdown
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </li> -->
      </ul>
    </div>

    <div class="col-md-4"> 
      <h2 class="m_s"> My Shop</h2>
    </div>



    <div class="col-md-4 fll"> 
      <form class="form-inline my-2 my-lg-0">
         <input type="text" class="form-control" placeholder="Product Name" aria-label="Recipient's username" aria-describedby="basic-addon2">
        <div class="input-group-append sr_bt">
          <button type="button"><i class="fa fa-search" ></i> </button>
        </div>
      </form>
    </div>

  </div>
  </div>
  </nav>
 
<!--  From products/show.blade --> 
   <?php echo $__env->yieldContent('content'); ?>  


<div class="footer"> 
  <p class="text-center">&copy 2019 All right reserved | My Shop Site</p>
</div>

 </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo e(asset('js/js/jquery-3.3.1.slim.min.js')); ?>" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/js/popper.min.js')); ?>" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/js/bootstrap.min.js')); ?>" crossorigin="anonymous"></script>

      </body>
</html>