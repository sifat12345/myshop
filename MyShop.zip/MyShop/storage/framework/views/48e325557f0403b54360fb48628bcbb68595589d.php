<?php $__env->startSection('title'); ?>
  <?php echo e($product->title); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- Start Sidebar + Content -->
  <div class='container h_m'>
    <div class="row">
      <div class="col-md-4">

      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">

          <?php
          $i = 1;  ?>
        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="p_item carousel-item <?php echo e($i == 1 ? 'active':''); ?>">
            <img class="d-block w-100" src="<?php echo asset('images/products/'. $image->image); ?>" alt="">
          </div>
          <?php
          $i++;  ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>

      </div>


      <div class="col-md-8">
        <div class="widget p_show">
          <h3>Name: <?php echo e($product->title); ?> </h3>
          <h4>Brand: <?php echo e($product->brand['name']); ?> </h4>
          <h4>Price: <?php echo e($product->price); ?>.Taka</h4>
          <p>Quantity: <span class="qq">
            <?php echo e($product->quantity < 1 ? 'Out of stock' : $product->quantity.'  In stock'); ?> </span>
          </p>
          <p>Category: <a href=""><?php echo e($product->category['name']); ?></a> </p>
          <div class="p_disc"> 
              <hr> <p>Description: <?php echo e($product->description); ?></p>
          </div>
        </div>

      </div>


    </div>
  </div>

  <!-- End Sidebar + Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>