@extends('backend.layouts.master')

@section('content')
  <div class="main-panel">
    <div class="content-wrapper">

      <div class="card">
        <div class="card-header">
          Add Division
        </div>
        <div class="card-body">
          <form action="{{ route('admin.division.store') }}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            @include('backend.partials.messages')
            <div class="form-group">
              <label for="name">Division Name</label>
              <input type="text" class="form-control" name="name" id="name" aria-describedby="emailHelp" placeholder="division name">
            </div>

            <div class="form-group">
              <label for="priority">Division Priority</label>
              <input type="text" class="form-control" priority="priority" name="priority" id="priority" aria-describedby="emailHelp" placeholder="division priority">
            </div>




            <button type="submit" class="btn btn-primary">Add  division</button>
          </form>
        </div>
      </div>

    </div>
  </div>
  <!-- main-panel ends -->
@endsection
