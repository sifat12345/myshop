@extends('frontend.layouts.master')

@section('content')
  <div class='container margin-top-20'>
    <h2>Contact Page</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi quidem saepe cum nihil velit illum atque corporis blanditiis, ipsa, expedita ad ea, ex ducimus enim ab. Modi non eveniet aperiam.</p>
  </div>
@endsection
