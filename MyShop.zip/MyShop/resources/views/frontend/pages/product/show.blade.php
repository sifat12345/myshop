@extends('frontend.layouts.master')

@section('title')
  {{ $product->title}} 
@endsection

@section('content')

  <!-- Start Sidebar + Content -->
  <div class='container h_m'>
    <div class="row">
      <div class="col-md-4">

      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">

          @php
          $i = 1;  @endphp
        @foreach ($product->images as $image)
          <div class="p_item carousel-item {{ $i == 1 ? 'active':'' }}">
            <img class="d-block w-100" src="{!! asset('images/products/'. $image->image)!!}" alt="">
          </div>
          @php
          $i++;  @endphp
        @endforeach
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>

      </div>


      <div class="col-md-8">
        <div class="widget p_show">
          <h3>Name: {{$product->title}} </h3>
          <h4>Brand: {{$product->brand['name']}} </h4>
          <h4>Price: {{$product->price}}.Taka</h4>
          <p>Quantity: <span class="qq">
            {{$product->quantity < 1 ? 'Out of stock' : $product->quantity.'  In stock' }} </span>
          </p>
          <p>Category: <a href="">{{ $product->category['name'] }}</a> </p>
          <div class="p_disc"> 
              <hr> <p>Description: {{$product->description}}</p>
          </div>
        </div>

      </div>


    </div>
  </div>

  <!-- End Sidebar + Content -->
@endsection
