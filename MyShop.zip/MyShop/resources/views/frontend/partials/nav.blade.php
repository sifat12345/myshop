

<nav class="navbar navbar-expand-lg navbar-light n_c">
<div class=" con_wid"> 


  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <div class="col-md-4"> 

      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="{{route('index')}}">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="{{route('contact')}}">Contact <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="{{route('products')}}">Products <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="{{route('admin.products')}}">Admin <span class="sr-only">(current)</span></a>
        </li>

      </ul>
 </div>

    <div class="col-md-4"> 
      <h2 class="m_s"> My Shop</h2>
    </div>

 <style>.ser{ margin-top: 3px;}  </style>

    <div class="col-md-4 fll"> 
      <div class="row"> 
       
         <div class="col-md-8  ser"> 
          <form class="form-inline my-2 my-lg-0" action="{!! route('search') !!}" method="get">
             <input type="text" class="form-control" name="sear" placeholder="Product Name" aria-label="Recipient's username" aria-describedby="basic-addon2">
            <div class="input-group-append sr_bt">
              <button type="submit"><i class="fa fa-search" ></i> </button>
            </div>
          </form>
         </div>

    <div class="col-md-4"> 
          <ul class="navbar-nav ml-auto">
              <!-- Authentication Links -->
          @guest
                  <a class=" nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>     
              @if (Route::has('register'))
                   <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>    

              @endif
          @else
              <li class="nav-item dropdown">
                  <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                      {{ Auth::user()->name }} <span class="caret"></span>
                  </a>

                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="{{ route('logout') }}"
                         onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();">
                          {{ __('Logout') }}
                      </a>

                      <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                          @csrf
                      </form>
                  </div>
              </li>
          @endguest
         </u>
           <!-- Edn Authentication Links -->
        </div>

     </div>
   </div>


  </div>

  </div>
</nav>
