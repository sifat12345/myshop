<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title> 
    @yield ('title', 'My Shop')
 </title>

  @include('frontend.partials.styles')
</head>
<body>

  <div class="wrapper" >
    
     <div class="m_b"style="min-height:555px;"> 
        @include('frontend.partials.nav')
        @yield('content')  
     </div>

        @include('frontend.partials.footer')

  </div>


  @include('frontend.partials.scripts')
  </body>
</html>
